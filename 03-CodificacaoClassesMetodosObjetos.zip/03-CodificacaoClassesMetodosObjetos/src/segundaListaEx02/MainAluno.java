package segundaListaEx02;

import java.util.Scanner;

public class MainAluno {
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        Aluno al = new Aluno();

        System.out.println("Bem vindo!");

        System.out.print("Informe o nome do aluno: ");
        al.nome = kb.next();
        System.out.print("Insira o número de matrícula do aluno: ");
        al.matricula = kb.nextInt();

        for (int i = 0; i < al.disciplina.length; i++) {
            System.out.print("\nInforme o nome da " + (i+1) + "° disciplina: ");
            al.disciplina[i] = kb.next();
            for (int j = 0; j < al.nota.length; j++) {
                System.out.print("Informa a nota da " + (i+1) + "° prova: ");
                al.nota[j] = kb.nextDouble();
            }
            al.media = (al.nota[0] + al.nota[1]) / 2;
            al.status = al.verificarStatus(al.media);

            System.out.print("\nNome: " + al.nome);
            System.out.print("\nNúmero de matrícula: " + al.matricula);
            System.out.print("\nDisciplina: " + al.disciplina[i]);
            System.out.print("\nMédia das notas: " + al.media);
            System.out.print("\nStatus: " + al.status);
            System.out.println();
        }
    }
}
