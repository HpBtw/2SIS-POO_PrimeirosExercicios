public class Aluno {
    // atributos ou propriedades ou variável de instância
    int rm;
    String nome;
    double mediaGeral;

    public static void main(String[] args) {
        // criação de objeto
        Aluno objeto = new Aluno();
        objeto.rm = 1000;
    }
}