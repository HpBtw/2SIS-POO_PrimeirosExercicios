package segundaListaEx03;

import java.util.Scanner;

public class MainPonto {
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        Ponto pt1 = new Ponto();
        Ponto pt2 = new Ponto();

        double origem = 0;

        System.out.print("Digite o X do ponto 1: ");
        pt1.x = kb.nextDouble();
        System.out.print("Digite o Y do ponto 1: ");
        pt1.y = kb.nextDouble();
        System.out.print("Digite o X do ponto 2: ");
        pt2.x = kb.nextDouble();
        System.out.print("Digite o Y do ponto 2: ");
        pt2.y = kb.nextDouble();

        double distancia = pt1.calcularDistancia(pt2);

        System.out.println("Distância entre os pontos: " + distancia);
        System.out.println("Distância entre a origem e o ponto 1: " + double distanciaOrigem = pt1.calcularDistanciaOrigem());
    }
}
