package segundaListaEx01;

import java.util.Scanner;

public class MainJogo {
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        Jogo jo = new Jogo();

        System.out.print("Digite seu nome: ");
        jo.nome = kb.next();

        for (int i = 0; i < jo.pontuacao.length; i++) {
            System.out.print("Digite a pontuação da " + (i+1) + "° rodada: ");
            jo.pontuacao[i] = kb.nextInt();
        }
        int pontuacaoTotal = jo.calcularPontuacao(jo.pontuacao);

        System.out.print("\nJogador: " + jo.nome);
        System.out.print("\nPontuação: " + pontuacaoTotal);
    }
}
