package ex03;

public class Banco {
    int agencia;
    int contaCorrente;
    int idade;
    double saldo = 0;
    String nome;
}
