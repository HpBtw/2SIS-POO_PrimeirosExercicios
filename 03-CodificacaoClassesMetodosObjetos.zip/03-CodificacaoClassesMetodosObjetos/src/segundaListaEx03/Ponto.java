package segundaListaEx03;

public class Ponto {
    double x;
    double y;

    public double calcularDistancia(Ponto pt2) {
        double distancia = Math.sqrt(Math.pow(x-pt2.x, 2) + Math.pow(y-pt2.y, 2));

        return distancia;
    }

    public double calcularDistanciaOrigem() {
        Ponto origem = new Ponto();
        origem.x = 0;
        origem.y = 0;

        double distanciaOrigem = calcularDistancia(origem);

        return distanciaOrigem;
    }

    public static Ponto maisProximoDaOrigem ()
}
