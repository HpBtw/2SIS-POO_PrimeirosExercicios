package exercicio04;

public class Funcionario {
    String nome;
    String cargo;
    double salario;

    // codificar o construtor de inicialização de atributos/valores recebidos
    public Funcionario(String nome, String cargo, double salario) {
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
    }

    public void aumentarSalario(double aumento) {
        salario += salario * aumento / 100;
    }

    public void aumentarSalario(String cargo, double aumento) {
        if(this.cargo.equalsIgnoreCase(cargo)) {
            salario += salario * aumento / 100;
        }
    }

    public void promover(String novoCargo) {
        cargo = novoCargo;
    }
}
