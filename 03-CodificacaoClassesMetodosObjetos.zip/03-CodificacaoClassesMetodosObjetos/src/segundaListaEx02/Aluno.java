package segundaListaEx02;

public class Aluno {
    int matricula;
    String nome;
    String[] disciplina = new String[3];
    String status;
    double[] nota = new double[2];
    double media;

    public String verificarStatus(double media) {
        String status;
        if (media >= 6) {
            status = "APROVADO";
        } else {
            status = "REPROVADO";
        }

        return status;
    }
}
