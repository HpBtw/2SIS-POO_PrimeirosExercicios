package exercicio04;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        double aumento;

        Scanner kb = new Scanner(System.in);
        Funcionario fu = new Funcionario("Ana", "diretor", 5000);

        System.out.print("Informe o valor em porcentagem (exemplo: 10 para 10%, 5 para 5%) a ser implementado no seu salário: ");
        aumento = kb.nextDouble();

        System.out.println("Salário: " + fu.salario);
        fu.aumentarSalario(aumento);
        System.out.println("Salário ajustado: " + fu.salario);
        fu.aumentarSalario("gerente", 10);
        System.out.println("Salário ajustado c/ cargo: " + fu.salario);
    }
}
