package segundaListaEx01;

public class Jogo {
    String nome;
    int[] pontuacao = new int[3];

    public int calcularPontuacao(int[] pontuacao) {
        int pontuacaoTotal = 0;

        for (int i = 0; i < pontuacao.length; i++) {
            pontuacaoTotal += pontuacao[i];
        }
        return pontuacaoTotal;
    }
}
